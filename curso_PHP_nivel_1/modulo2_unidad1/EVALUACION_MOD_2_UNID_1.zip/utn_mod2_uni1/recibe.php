<?php
echo "El producto elegido es: ";
echo $_GET['producto'];
echo "<br><br>";
echo "Caracteristicas principales: ";
echo $_GET['caracteristicas'];
echo "<br><br>";
echo "Su precio es: ";
echo $_GET['precio'];
echo "<br><br>";
echo "<img src='".$_GET['imagen'].".jpg'>";