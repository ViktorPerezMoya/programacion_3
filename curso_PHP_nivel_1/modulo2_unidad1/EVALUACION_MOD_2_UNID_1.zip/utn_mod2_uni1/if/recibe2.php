<?php
$val1 = $_POST['valor1'];
$val2 = $_POST['valor2'];
$oper = $_POST['operacion'];


echo $val1.' '.$oper.' '.$val2.'=';
if($oper == "+"){
    echo $val1 + $val2;
}elseif($oper == "-"){
    echo $val1 - $val2;
}elseif($oper == "*"){
    echo $val1 * $val2;
}elseif($oper == "/"){
    echo $val1 / $val2;
}else{
    echo "ERROR!!";
}