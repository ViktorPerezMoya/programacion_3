<?php
$val1 = $_POST['valor1'];
$val2 = $_POST['valor2'];
$oper = $_POST['operacion'];


echo $val1.' '.$oper.' '.$val2.'=';
switch ($oper) {
    case '+':
        echo $val1 + $val2;
        break;
    case '-':
        echo $val1 - $val2;
        break;
    case '*':
        echo $val1 * $val2;
        break;
    case '/':
        echo $val1 / $val2;
        break;
    default:
        echo "ERROR!!";
        break;
}   