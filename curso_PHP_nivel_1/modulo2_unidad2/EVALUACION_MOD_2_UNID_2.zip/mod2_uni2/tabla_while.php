<?php
$nro_tabla = 5;
$indice = 1;

while($indice <= 10){
    $res = $indice *  $nro_tabla;
    echo $nro_tabla.' x '.$indice.' = '.$res;
    echo '<br>';
    $indice++;
}