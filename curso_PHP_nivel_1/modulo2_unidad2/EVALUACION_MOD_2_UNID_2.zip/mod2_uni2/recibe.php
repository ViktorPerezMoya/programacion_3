<?php

$val = $_POST['numero'];

$fact = 1;
$cont = 1;
while($cont <= $val){
    $fact = $fact * $cont;
    $cont ++;
}

echo "El factorial es $fact";