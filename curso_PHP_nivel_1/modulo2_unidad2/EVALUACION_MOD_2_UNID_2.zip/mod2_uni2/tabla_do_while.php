<?php
$nro_tabla = 5;
$indice = 1;

do{
    $res = $indice *  $nro_tabla;
    echo $nro_tabla.' x '.$indice.' = '.$res;
    echo '<br>';
    $indice++;
}while($indice <= 10);