<?php
include 'Carrito.php';
session_start();

$index = $_GET['i'];
$carrito = new Carrito();
$carrito->elimina_producto($index);


?>
<h1>Eliminación exitosa!!</h1>
<h3><a href="inicio.php"> << VOLVER</a></h3>