<?php

include 'Carrito.php';
include 'ProductoBD.php';

session_start();
$codigo = $_GET['codigo'];

$pBD = new ProductoBD();
$p = $pBD->buscar($codigo);

$carrito = new Carrito();
$carrito->introduce_producto(['codigo' => $p->codigo, 'producto' => $p->producto, 'precio' => $p->precio]);

?>
<h1>Carga exitosa!!</h1>
<h3><a href="inicio.php"> << VOLVER</a></h3>
