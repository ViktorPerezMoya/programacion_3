<?php
include 'DAOInterface.php';
include 'Producto.php';
include 'BD.php';
class ProductoBD implements DAOInterface{
    function listar(){

        $productos = array();

        $conn = BD::conectar();
        $result_array = $conn->query('SELECT * from productos');
        foreach($result_array as $row){
            $prod = new Producto($row);
            array_push($productos, $prod);
        }

        $conn = null;

        return $productos;
    }

    function buscar($codigo){
        $producto = null;
        $conn = BD::conectar();
        $query = $conn->prepare('SELECT * FROM productos WHERE codigo = ? LIMIT 1');
        if($query->execute([$codigo])){
            while($row = $query->fetch()){
                $producto = new Producto($row);
            }
        }

        return $producto;
    }
}