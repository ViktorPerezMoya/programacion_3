<?php
class BD{
    public static function conectar(){
         return new PDO('mysql:host=localhost;dbname=carro_compras', 'root', '');
    }
}