<?php
interface DAOInterface{
    function listar();
    function buscar($codigo);
}