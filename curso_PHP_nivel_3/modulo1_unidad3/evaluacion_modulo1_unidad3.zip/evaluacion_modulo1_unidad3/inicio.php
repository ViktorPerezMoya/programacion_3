<?php session_start(); ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Carrito</title>
        <meta charset="utf-8"/>
        <style>
            div.carrito thead{
                background-color: purple;
                color: white;
            }
            div.articulos thead{
                background-color: tomato;
            }
            tbody tr:nth-child(odd){
                background-color:#f2f2f2;;
            }
            tbody tr:nth-child(even){
                background-color:#fbfbfb;
            }
        </style>
    </head>
    <body>
        <div class="carrito">
            <h2>Carrito</h2>
            <?php //var_dump($_SESSION['carrito']);?>
            <table>
                <thead>
                    <tr>
                        <th>código</th>
                        <th>producto</th>
                        <th>precio</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    include 'Carrito.php';
                    $carrito = new Carrito();
                    $carrito->imprime_carrito();
                    ?>
                </tbody>
            </table>
        </div>
        <hr>
        <div class="articulos">
            <h2>Articulos</h2>
            <table>
                <thead>
                    <tr>
                        <th>código</th>
                        <th>producto</th>
                        <th>descripción</th>
                        <th>precio</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php 
                    include 'ProductoBD.php';
                    $pBD = new ProductoBD();
                    $productos = $pBD->listar();
                    foreach($productos as $p){
                        echo '<tr>';
                        echo '<td>'.$p->codigo.'</td>';
                        echo '<td>'.$p->producto.'</td>';
                        echo '<td>'.$p->descripcion.'</td>';
                        echo '<td>'.$p->precio.'</td>';
                        echo '<td><a href="intro_prod.php?codigo='.$p->codigo.'">Introducir</a></td>';
                        echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </body>
</html>