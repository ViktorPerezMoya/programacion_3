<?php
class Carrito {
    private $num_productos = 0;
    
    function __construct() {
        if(sizeof($_SESSION['carrito']) == 0){
            $_SESSION['carrito'] = array();
        }
    }

    
    public function introduce_producto($prod = null){
        if(is_null($prod))
            return;
        
        array_push($_SESSION['carrito'], $prod);
        $this->num_productos = sizeof($_SESSION['carrito']);
        
    }
    
    public function imprime_carrito(){
        
        foreach($_SESSION['carrito'] as $index => $prod){
            echo '<tr>'.
            '<td>'.$prod["codigo"].'</td>'.
            '<td>'.$prod['producto'].'</td>'.
            '<td>'.$prod['precio'].'</td>'.
            '<td><a href="remove_item.php?i='.$index.'">eliminar</a></td>'.
            '</tr>';
        }

    }
    
    public function elimina_producto($index){
        unset($_SESSION['carrito'][$index]);
    }
}