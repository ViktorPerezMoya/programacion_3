<?php 
class Producto{
    public $codigo;
    public $producto;
    public $descripcion;
    public $precio;

    public function __construct($data = array()){
        $this->codigo = $data['codigo'];
        $this->producto = $data['producto'];
        $this->descripcion = $data['descripcion'];
        $this->precio = $data['precio'];
    }

}