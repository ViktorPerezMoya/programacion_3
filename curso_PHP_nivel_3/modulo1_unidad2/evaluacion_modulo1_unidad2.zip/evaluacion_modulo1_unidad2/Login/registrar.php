<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<?php
include ('conect.php');

mysqli_query ($conexion, "INSERT INTO usuarios VALUES ('".$_POST['usuario']."', '".$_POST['password']."', '".$_POST['nombre']."', '".$_POST['apellido']."', '".$_POST['email']."', ".$_POST['dni'].")");

try{

if (mysqli_errno($conexion) == 0){
	throw new Exception('El usuario ha sido dado de alta <a href="inicio.html">Ingresar</a>');
}
else{
	if (mysqli_errno($conexion) == 1062){

		throw new Exception('Ese nombre de usuario ya existe en la base de datos');		
	}
	else{
		throw new Exception('Error al insertar: '.mysqli_error($conexion));
	}
}

}catch(Exception $e){
	echo $e->getMessage();
}
?>
</body>
</html>