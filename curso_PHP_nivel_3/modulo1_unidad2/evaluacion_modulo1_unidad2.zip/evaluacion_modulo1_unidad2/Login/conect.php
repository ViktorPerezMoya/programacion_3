
<?php
$conexion=mysqli_connect("localhost", "root", "","login") 
or exit("No se pudo establecer una conexión");
?>





