<?php

include ('./Persona.php');

$persona = new Persona("Victor","Perez","1990-06-25");
$persona->imprime_caracteristicas();