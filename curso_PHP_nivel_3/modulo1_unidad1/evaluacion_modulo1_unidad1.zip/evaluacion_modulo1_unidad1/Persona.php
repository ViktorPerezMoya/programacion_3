<?php

class Persona{
	private $nombre;
	private $apellido;
	private $fecha_nacimiento;

	public function __construct($nomb,$apel,$fena){
		$this->nombre = $nomb;
		$this->apellido =$apel;
		$this->fecha_nacimiento = $fena;
	}

	private function calcular_edad(){
		$year_fena = explode("-",$this->fecha_nacimiento)[0];
		$year_now = date("Y");

		return ($year_now - $year_fena);
	}

	public function imprime_caracteristicas(){
		echo "Nombre: ".$this->nombre."<br>";
		echo "Apellido: ".$this->apellido."<br>";
		echo "Fecha de Nacimiento: ".$this->fecha_nacimiento."<br>";
		echo "Edad: ".$this->calcular_edad()."<br>";
	}
}