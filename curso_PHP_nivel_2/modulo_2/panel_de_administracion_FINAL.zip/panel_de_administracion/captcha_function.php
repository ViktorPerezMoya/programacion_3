<?php
function generate_captcha(){
    $numero1= rand(0,9);
    $numero2= rand(0,9);
    $numero3= rand(0,9);
    $minus = array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z");
    $mayus = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
    $signos = array("!","#","$","%","&","=");

    $generador_min = rand(0,25);
    $generador_may = rand(0,25);
    $generador_sig = rand(0,5);

    $_SESSION["captcha_code"] = ($numero1).($minus[$generador_min]).($numero2).($mayus[$generador_may]).($signos[$generador_sig]); // Guardamos el texto del CAPTCHA en la sesion
    
    return "<img src=captcha_imagen.php>";
}
?>
