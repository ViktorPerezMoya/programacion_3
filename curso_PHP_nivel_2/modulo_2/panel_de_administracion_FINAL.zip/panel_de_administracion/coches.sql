-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-12-2018 a las 21:48:23
-- Versión del servidor: 10.1.34-MariaDB
-- Versión de PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `coches`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

CREATE TABLE `marcas` (
  `id` int(11) NOT NULL,
  `marca` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`id`, `marca`) VALUES
(1, 'Alfa Romeo'),
(2, 'Audi'),
(3, 'BMW'),
(4, 'Chevrolet'),
(5, 'Chrysler'),
(6, 'Citroen'),
(7, 'Daewoo'),
(8, 'Fiat'),
(9, 'Ford'),
(10, 'Honda'),
(11, 'Hyundai'),
(12, 'Jeep'),
(13, 'Kia'),
(14, 'Lancia'),
(15, 'Lexus'),
(16, 'Mazda'),
(17, 'Mercedes-Benz'),
(18, 'Mitsubushi'),
(19, 'Nissan'),
(20, 'Opel'),
(21, 'Peugeot'),
(22, 'Porsche'),
(23, 'Renault'),
(24, 'Rover'),
(25, 'Saab'),
(26, 'Seat'),
(27, 'Skoda'),
(28, 'Toyota'),
(29, 'Volskwagen'),
(30, 'Volvo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ocasion`
--

CREATE TABLE `ocasion` (
  `id` int(3) NOT NULL,
  `idmarca` int(11) NOT NULL,
  `modelo` varchar(20) CHARACTER SET latin1 NOT NULL,
  `combustible` varchar(10) CHARACTER SET latin1 NOT NULL,
  `color` varchar(15) CHARACTER SET latin1 NOT NULL,
  `fecha` int(4) NOT NULL DEFAULT '0',
  `precio` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ocasion`
--

INSERT INTO `ocasion` (`id`, `idmarca`, `modelo`, `combustible`, `color`, `fecha`, `precio`) VALUES
(2, 21, '206 GTI', 'nafta', 'gris quartz', 2006, 38000),
(3, 8, '147', 'nafta', 'verde militar', 1999, 45000),
(4, 5, 'Neon', 'nafta', 'violeta parra', 1998, 26000),
(5, 4, 'chevy SS', 'nafta', 'naranja', 1975, 18000),
(6, 8, '600', 'nafta', 'azul', 1981, 8000),
(7, 4, 'chevy SS', 'nafta', 'naranja', 1973, 18000),
(8, 4, 'chevy SS', 'nafta', 'naranja', 1973, 18000),
(9, 2, 'TT', 'nafta', 'negro azabache', 2007, 578000),
(10, 9, 'fairlane', 'nafta', 'negro olmedo', 1969, 12300),
(11, 2, 'A4', 'nafta', 'gris', 2014, 300000),
(18, 2, 'A3', 'nafta', 'azul electrico', 2009, 120000),
(20, 9, 'Ecosport', 'nafta', 'Rojo', 2012, 180000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(30) DEFAULT NULL,
  `clave` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `clave`) VALUES
(1, 'admin', '123');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `marcas`
--
ALTER TABLE `marcas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ocasion`
--
ALTER TABLE `ocasion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `marcas`
--
ALTER TABLE `marcas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `ocasion`
--
ALTER TABLE `ocasion`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
