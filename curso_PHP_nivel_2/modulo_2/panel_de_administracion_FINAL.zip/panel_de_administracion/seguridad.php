<?php
session_start();
if(empty($_SESSION['usuario'])){
    $_SESSION['msg_error'] = "El usuario no esta logeado";
    header('Location: index.php');
}