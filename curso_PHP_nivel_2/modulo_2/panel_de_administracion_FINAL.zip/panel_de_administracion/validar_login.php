<?php

session_start();
include("conecta.php");
$code = $_POST['captcha_confirm'];
if($code != $_SESSION['captcha_code']){
    $_SESSION['msg_error'] ="El chapcha es incorrecto";
    header('Location: index.php');
    exit();
}
$usuario = $_POST['usuario'];
$clave = $_POST['clave'];

$result = mysqli_query($conexion, "SELECT  * FROM usuarios WHERE usuario = '$usuario' AND  clave = '$clave'") or die (msqli_error($conexion));

$existe=  false;
while ($row = mysqli_fetch_assoc($result)) {
    $_SESSION['usuario'] = $row['usuario'];
    $existe = true;
    break;
}
mysqli_free_result($result);
mysqli_close($conexion);

if($existe){
    unset($_SESSION['captcha_confirm']);
    header('Location: index1.php');
}else{
    $_SESSION['msg_error'] ="Usuario o clave invalidos.";
    header('Location: index.php');
}
