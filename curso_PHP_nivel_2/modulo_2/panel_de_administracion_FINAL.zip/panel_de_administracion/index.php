<?php
session_start();
if (isset($_SESSION['usuario'])) {
    header('Location: index1.php');
}
include("./captcha_function.php");
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>Administrador - PHP y MySQL Intermedio</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
        <link href="css/font-awesome.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/estilos_victor.css" rel="stylesheet">
        <link href="css/pages/dashboard.css" rel="stylesheet">
        <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
              <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
            <![endif]-->
    </head>
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span><span class="icon-bar"></span>
                        <span class="icon-bar"></span> </a><a class="brand" href="index.php">
                        <img src="img/lambo.png" width="100" height="30"> Login </a>

                    <div class="nav-collapse">

                    </div>
                    <!--/.nav-collapse --> 
                </div>
                <!-- /container --> 
            </div>
            <!-- /navbar-inner --> 
        </div>
        <!-- /login -->

        <?php
        if (!empty($_SESSION['msg_error'])) {
            ?>
            <div class="alert alert-danger message_alert" role="alert">
                <p><?= $_SESSION['msg_error'] ?></p>    
            </div>
            <?php
            unset($_SESSION['msg_error']);
        }

// fin de mensaje de alerta
        ?>
        <div class="container">
            <div class="row">
                <div class="col-offset-4 col-4">
                    <form method="post" action="validar_login.php" class="form-login">
                        <fieldset>
                            <legend>Login</legend>

                            <div class="form-group">
                                <label for="usuario">Usuario</label>
                                <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Usuario">
                            </div>
                            <div class="form-group">
                                <label for="clave">Clave</label>
                                <input type="password" class="form-control" id="clave" name="clave" placeholder="Clave">
                            </div>
                            <div class="form-group">
                                <label>Captcha: </label>
                                <?php print generate_captcha(); ?><br>
                                <input type="text" name="captcha_confirm" class="form-control">

                            </div>
                            <button type="submit" class="btn btn-default">Loguin</button>
                        </fieldset>
                    </form>
                </div>
            </div>

        </div>

        <!-- footer -->
        <div class="footer">
            <div class="footer-inner">
                <div class="container">
                    <div class="row">
                        <div class="span12"><a href="#">PHP y MySQL Intermedio</a>. </div>
                        <!-- /span12 --> 
                    </div>
                    <!-- /row --> 
                </div>
                <!-- /container --> 
            </div>
            <!-- /footer-inner --> 
        </div>
        <!-- /footer --> 
        <script src="js/jquery-1.7.2.min.js"></script> 
        <script src="js/excanvas.min.js"></script> 
        <script src="js/chart.min.js" type="text/javascript"></script> 
        <script src="js/bootstrap.js"></script>
        <script language="javascript" type="text/javascript" src="js/full-calendar/fullcalendar.min.js"></script>

        <script src="js/base.js"></script> 
    </body>
</html>
