<?php // Conexion a la base
$conexion=mysqli_connect("localhost", "root", "","coches") 
or exit("No se pudo establecer una conexión");

?>